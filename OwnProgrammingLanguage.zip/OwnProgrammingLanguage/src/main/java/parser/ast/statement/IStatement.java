package parser.ast.statement;

public interface IStatement {
    void execute();
}
