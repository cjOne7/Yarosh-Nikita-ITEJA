package parser.ast.expression;

public interface IExpression {
    double eval();
}
